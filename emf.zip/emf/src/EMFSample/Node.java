/**
 */
package EMFSample;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see EMFSample.EMFSamplePackage#getNode()
 * @model
 * @generated
 */
public interface Node extends NamedElement {
} // Node
